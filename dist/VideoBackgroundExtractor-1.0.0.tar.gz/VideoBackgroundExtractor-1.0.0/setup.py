from setuptools import setup, find_packages

setup(
    name='VideoBackgroundExtractor',
    version='1.0.0',
    author="Henrique Schmitz",
    packages=find_packages()
)